# Notification

可恢复的 CLI 通知。

写入／生成：P2 通知服务。存储：notification。

完整机器契约：[contracts.schema.json](../contracts.schema.json)，`#/$defs/Notification`。

## 字段

| 字段 | 类型 | 必需 | 含义 |
|---|---|---|---|
| schema_version | 1 | 是 | 契约 major 版本 |
| id | string | 是 | UUID 标识 |
| run_id | string / null | 是 | 见类型定义 |
| notification_key | string | 是 |  |
| state | enum | 是 | ；PENDING, DELIVERED, ACKNOWLEDGED |
| text | string | 是 |  |
| created_at | string | 是 | UTC RFC3339 时间 |
| delivered_at | string / null | 是 | 见类型定义 |
| acknowledged_at | string / null | 是 | 见类型定义 |
| extensions | object | 是 | 有命名空间的可选扩展 |

## 约束与使用

持久入库不等于 Master 已看到或确认。

通用空值、版本、扩展、引用和错误规则见 [Common.md](Common.md)；事件与提交关系见 [DataFlow.md](../DataFlow.md)。
