# ScheduledJob

持久触发计划与任务模板。

写入／生成：共享 CommandService；P2 推进时点。存储：scheduled_job。

完整机器契约：[contracts.schema.json](../contracts.schema.json)，`#/$defs/ScheduledJob`。

## 字段

| 字段 | 类型 | 必需 | 含义 |
|---|---|---|---|
| schema_version | 1 | 是 | 契约 major 版本 |
| id | string | 是 | UUID 标识 |
| revision | integer | 是 |  |
| root_id | string | 是 | UUID 标识 |
| enabled | boolean | 是 |  |
| schedule | Schedule | 是 | 见类型定义 |
| command | Command | 是 | 见类型定义 |
| task_template | object | 是 | 见类型定义 |
| next_due_at | string / null | 是 | 见类型定义 |
| misfire | enum | 是 | ；SKIP, FIRE_ONCE_WITHIN_GRACE |
| grace_seconds | integer | 是 |  |
| overlap | SKIP | 是 | 见类型定义 |
| max_attempts | integer | 是 | 见类型定义 |
| updated_at | string | 是 | UTC RFC3339 时间 |
| extensions | object | 是 | 有命名空间的可选扩展 |

## 约束与使用

schedule.kind 对条件字段二次校验；无关字段必须 null/空数组。event 型 next_due_at 为 null，通过持久游标触发。

通用空值、版本、扩展、引用和错误规则见 [Common.md](Common.md)；事件与提交关系见 [DataFlow.md](../DataFlow.md)。
