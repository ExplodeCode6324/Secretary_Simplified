# 类型注册表与模型角色

## 1. 初版值类型

注册表由程序配置和代码加载、版本化，不接受模型临时登记。下列测试类型必须在阶段 1 固定为严格对象 Schema，未知字段拒绝；来源适配器以后以新增类型迁移扩展。

| 用途与类型名 | value/normalized 字段 | 约束 |
|---|---|---|
| source `fixture.item` | title:string、domain:string、due_at:timestamp/null、status:Item.status | 合成源事项；external_id 决定同一来源身份 |
| observation `device.availability` | available:boolean、device_id:string | valid_until 必填 |
| observation `source.health` | source_id:UUID、reachable:boolean | 只表示该次检查 |
| fact `master.preference` | key:string、value:string | 单值 key 范围；Master 明确输入优先 |
| fact `project.background` | project_id:UUID、text:string | 背景材料需溯源，不当作当前执行状态 |
| fact `entity.relation` | relation:string、target_entity_id:UUID | 默认多值，关系类型白名单 |

predicate 的单值键包括 entity_id、predicate 与注册的子键（master.preference 的 key）。冲突识别必须按该键执行，不能把不同偏好错误合并。测试域在配置登记固定 entity IDs 和来源 ID，不使用任意字符串前缀作为真实授权。

ChangeEvent 的初始 event_type 为 item.created、item.updated、task.updated、world.updated、run.updated、source.synced、memory.refreshed。change 包含 before、after 和 evidence；before/after 为该 entity_type 的完整 DTO 或 null，创建时 before=null，删除／撤回语义按对应 DTO 保留。由类型注册表二次验证，至少一侧非空，after 的版本与 entity_revision 一致。事件保留变更前后值，使历史水位能重建，不依赖已经被覆盖的当前行。

能力参数、ActionProposal、Control、Criterion 的判别联合已经写入 [contracts.schema.json](../contracts.schema.json)。必须执行其中 allOf/if/then 的分支规则，不能只验证 arguments/payload 是对象。Artifact 的期望哈希来自可审查内容，world_revision 来自预期修改，notification_key 来自任务意图；初始 criterion 必须与已接受的输入语义一致，不能接受模型自行选择“总是成功”的标准。

## 2. 模型角色和输出

| 调用角色 | 输入 | 模型输出 Schema | 程序补充的元数据 |
|---|---|---|---|
| 即时理解／任务决策 | Context | DecisionEnvelope | intent、decision ID、身份、授权、提交回执 |
| 世界事实提取 | 受控原文片段、现有事实、准入规则 | WorldUpdateProposal | 许可、proposal hash；校验 model 提案引用不越界 |
| 每日认知整理 | ConsciousnessStateInput | ConsciousnessDraft | 快照 ID、slot、hash、时间、水位、revision |
| 会话摘要 | 原文序列、旧摘要、事项引用 | ConversationSummaryDraft | 会话 revision、覆盖水位 CAS |
| 晨报 | 只读 Context | DecisionEnvelope，actions/controls 必须为空 | 产物引用及任务执行回执 |

ConsciousnessDraft 只包含 focal_goals、priority_items、open_loops、important_changes、uncertainties、brief_summary。ConversationSummaryDraft 只包含 summary、focus_entity_ids、pending_question_ids、commitment_item_ids。后台输出 Schema 按角色明确选择并实际嵌入请求，不强迫每个后台生成器输出对 Master 的闲聊。

快照身份、slot、源水位和授权属于程序字段。即使模型在扩展中返回这些名称也不采用；只有合法的内容字段能合入持久结构。自由文本背景无法全部机械证明正确，阶段 3 真实模型评估和阶段 4 日常使用分别检验。

## 3. 动作组合规则

同一 Decision 最多 10 个 actions、3 个 controls，operation_key 唯一。等待、重规划、请求完成等修改同一 Task 状态的控制一次最多一项，不能同轮对同一 Task 同时 WAIT 和 REQUEST_COMPLETION。READ_MEMORY 可以独立请求，不得附带副作用 actions；它消耗预算后重新组装 Context。

一个 intent 的首个合法命令组提交成功后即封闭该组；同输入的再次模型响应只返回已保存回执。若需要后续步骤，通过已有 Task 的 REPLAN、WAIT 或新的明确用户输入表达，不能偷偷添加新 operation_key 绕过幂等。
