# Context

实际送入模型的有界结构化上下文。

写入／生成：P1 ContextBuilder。存储：文件对象 + context_manifest。

完整机器契约：[contracts.schema.json](../contracts.schema.json)，`#/$defs/Context`。

## 字段

| 字段 | 类型 | 必需 | 含义 |
|---|---|---|---|
| schema_version | 1 | 是 | 契约 major 版本 |
| manifest | ContextManifest | 是 | 见类型定义 |
| system_rules | string | 是 |  |
| current_input | InputEnvelope | 是 | 见类型定义 |
| world | WorldModelInput | 是 | 见类型定义 |
| live | LiveWorldStateInput | 是 | 见类型定义 |
| consciousness | ConsciousnessState / null | 是 | 见类型定义 |
| conversation | ConversationState | 是 | 见类型定义 |
| recent_events | array&lt;ConversationEvent&gt; | 是 |  |
| tasks | array&lt;Task&gt; | 是 |  |
| delta_events | array&lt;ChangeEvent&gt; | 是 |  |
| retrieved_evidence | array&lt;EvidenceRef&gt; | 是 |  |
| capability_ids | array&lt;string&gt; | 是 |  |
| output_contract | object | 是 | 实际嵌入对应 JSON Schema，不只放名字 |
| extensions | object | 是 | 有命名空间的可选扩展 |

## 约束与使用

manifest 哈希及计量字段属于本地外层，不参与最终模型请求序列化；只发送其余字段和必要只读元信息。公开 capability_ids 不包含令牌。

通用空值、版本、扩展、引用和错误规则见 [Common.md](Common.md)；事件与提交关系见 [DataFlow.md](../DataFlow.md)。
