# Verification

针对固定标准的验收记录。

写入／生成：P1 Verifier。存储：verification。

完整机器契约：[contracts.schema.json](../contracts.schema.json)，`#/$defs/Verification`。

## 字段

| 字段 | 类型 | 必需 | 含义 |
|---|---|---|---|
| schema_version | 1 | 是 | 契约 major 版本 |
| id | string | 是 | UUID 标识 |
| task_id | string | 是 | UUID 标识 |
| criterion_hash | string | 是 | SHA-256 十六进制摘要 |
| results | array&lt;object&gt; | 是 |  |
| verifier_version | string | 是 |  |
| created_at | string | 是 | UTC RFC3339 时间 |
| extensions | object | 是 | 有命名空间的可选扩展 |

## 约束与使用

每个 criterion_id 恰好一个结果，全部 PASS 才能完成；UNKNOWN 保留等待或需关注。

通用空值、版本、扩展、引用和错误规则见 [Common.md](Common.md)；事件与提交关系见 [DataFlow.md](../DataFlow.md)。
