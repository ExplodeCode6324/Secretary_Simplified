# ConsciousnessState

24 小时认知快照。

写入／生成：P1 memory.refresh。存储：consciousness_snapshot。

完整机器契约：[contracts.schema.json](../contracts.schema.json)，`#/$defs/ConsciousnessState`。

## 字段

| 字段 | 类型 | 必需 | 含义 |
|---|---|---|---|
| schema_version | 1 | 是 | 契约 major 版本 |
| id | string | 是 | UUID 标识 |
| revision | integer | 是 |  |
| slot | integer | 是 |  |
| snapshot_seq | integer | 是 |  |
| previous_snapshot_id | string / null | 是 | 见类型定义 |
| input_hash | string | 是 | SHA-256 十六进制摘要 |
| created_at | string | 是 | UTC RFC3339 时间 |
| focal_goals | array&lt;FocusEntry&gt; | 是 |  |
| priority_items | array&lt;FocusEntry&gt; | 是 |  |
| open_loops | array&lt;FocusEntry&gt; | 是 |  |
| important_changes | array&lt;FocusEntry&gt; | 是 |  |
| uncertainties | array&lt;string&gt; | 是 |  |
| brief_summary | string | 是 |  |
| missed_slots | integer | 是 |  |
| extensions | object | 是 | 有命名空间的可选扩展 |

## 约束与使用

旧快照可以继续展示但 Context 校正过期引用；slot 唯一。首次 bootstrap 同样服从证据与引用校验。

通用空值、版本、扩展、引用和错误规则见 [Common.md](Common.md)；事件与提交关系见 [DataFlow.md](../DataFlow.md)。
