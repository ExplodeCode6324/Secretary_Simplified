# Task

带完成标准的任务实例。

写入／生成：共享 TaskService；P1 验收。存储：task。

完整机器契约：[contracts.schema.json](../contracts.schema.json)，`#/$defs/Task`。

## 字段

| 字段 | 类型 | 必需 | 含义 |
|---|---|---|---|
| schema_version | 1 | 是 | 契约 major 版本 |
| id | string | 是 | UUID 标识 |
| revision | integer | 是 |  |
| root_id | string | 是 | UUID 标识 |
| item_id | string / null | 是 | 见类型定义 |
| job_id | string / null | 是 | 见类型定义 |
| occurrence_key | string / null | 是 | 见类型定义 |
| goal | string | 是 |  |
| state | enum | 是 | ；PENDING, RUNNING, VERIFYING, WAITING, NEEDS_ATTENTION, SUCCEEDED, FAILED, CANCELLED |
| criteria | array&lt;Criterion&gt; | 是 |  |
| criterion_hash | string | 是 | SHA-256 十六进制摘要 |
| cancel_generation | integer | 是 |  |
| deadline_at | string / null | 是 | 见类型定义 |
| created_at | string | 是 | UTC RFC3339 时间 |
| updated_at | string | 是 | UTC RFC3339 时间 |
| extensions | object | 是 | 有命名空间的可选扩展 |
| parent_root_id | string / null | 是 | 见类型定义 |

## 约束与使用

criteria 至少 1 项。周期任务每 occurrence 一个实例，计划 payload 保存任务模板。等待不得清空预算。

通用空值、版本、扩展、引用和错误规则见 [Common.md](Common.md)；事件与提交关系见 [DataFlow.md](../DataFlow.md)。
