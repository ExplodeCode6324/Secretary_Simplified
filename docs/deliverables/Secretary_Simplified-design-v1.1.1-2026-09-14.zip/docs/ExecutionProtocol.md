# 调度与执行协议

## 1. 对象分工

Item 是业务事项；Task 是具有固定完成条件的委托；ScheduledJob 是何时运行某个能力的持久计划；JobRun 是一次触发；ExecutionAttempt 是该触发的一次执行尝试。循环计划的每个 occurrence 创建独立 Task 实例并复制任务模板的完成条件，模板本身不标为完成。所有实例带 job_id 与 occurrence_key。

Command 是已校验参数的执行命令。DecisionEnvelope 只提交命令提案，程序分配 ID、授权和运行状态。Task 的 criterion 在接收时保存不可变版本及哈希；重新规划只能换执行办法，修改目标必须创建新的 intent/criterion 版本并保留旧记录。

## 2. 稳定身份与原子登记

InputEnvelope.request_id 由客户端生成并重试复用。Core 为该输入分配 intent_id；非交互事件使用稳定因果根。一个意图中的动作由 operation_key 区分，唯一键为 `(intent_id, operation_key)`，不能包含本轮模型调用 ID。模型第一次合法输出后固定 operation_key 到动作语义的绑定，重算不能靠换 key 重复同一动作；新增动作必须在同一意图的持久 action ledger 检查语义和预算。

每个请求保存 canonical_payload_hash。相同键、相同规范载荷返回原回执；相同键、不同载荷返回 IDEMPOTENCY_CONFLICT。摘要哈希使用契约定义的确定性 JSON 编码，键排序、无无关空白、数组保序；禁止 NaN/Infinity。

发生业务修改、任务登记、计划登记时，所有修改与 ChangeEvent、request_receipt 同事务。时间触发以 `(job_id, scheduled_for_utc)` 形成 occurrence_key；事件触发以 `(job_id, event_id)` 形成 occurrence_key；手动触发以 `(job_id, request_id)` 形成 occurrence_key。job_revision 作为执行快照保存，不进入重复触发身份，避免编辑计划后重发同一时点。重试 attempt 沿用同一 run_id 和 external_idempotency_key。

## 3. 触发规则

| 类型 | 必填输入 | 规则 |
|---|---|---|
| immediate | command | 提交后立即创建 run |
| once | at | RFC3339 时间，转成 UTC |
| interval | anchor_at、every_seconds | 固定经过时长，every_seconds >= 60 |
| daily | local_time、timezone | IANA 时区，每日本地时刻 |
| weekly | local_time、timezone、weekdays | weekday 为 ISO 1—7，无重复 |
| event | event_type、filter、after_seq | 结构化字段过滤，禁止可执行表达式 |

日历时间不存在时跳过该次并记事件；重复时间选择第一次出现的 UTC 时刻，每个本地日期只触发一次。更改时区或规则递增 job revision，重新计算 next_due_at。已经派发的旧 run 保留原快照；尚未派发的旧 run 取消且保留已消费的 occurrence_key。若 Master 明确要在同一时点重新执行已登记的 occurrence，用新请求创建新的单次计划并显示替代关系，不靠改 revision 重发。默认 overlap=SKIP；新的 occurrence 仍保存 SKIPPED 回执，不能悄悄消失。

misfire 默认 SKIP，提醒默认 FIRE_ONCE_WITHIN_GRACE，宽限默认 5 分钟。周期计划最多补最近一个允许的 occurrence，其余记录聚合遗漏计数；不无限补历史任务。长时间停机不形成突发执行风暴。每日认知任务按 MemoryPolicy 的当前槽补偿例外规则。

## 4. 状态机

Task：`PENDING → RUNNING → VERIFYING → SUCCEEDED`。任一非终态可进入 WAITING、NEEDS_ATTENTION、FAILED、CANCELLED；WAITING 被合法事件或超时唤醒后回到 PENDING。VERIFYING 验证未通过可在剩余预算内重新规划，否则 NEEDS_ATTENTION。SUCCEEDED/FAILED/CANCELLED 终态不复用；新目标新建任务。

JobRun：`QUEUED → CLAIMED → RUNNING → SUCCEEDED | FAILED | RESULT_UNKNOWN | CANCELLED`；未执行的触发可以 SKIPPED。已过期 CLAIMED 如能证明未派发可回 QUEUED；否则进入 RESULT_UNKNOWN。Attempt 记录 PREPARED、DISPATCHED 和最终结果，不能仅靠进程消失判定未执行。

RESULT_UNKNOWN 经对账可到 SUCCEEDED/FAILED；只有证明未产生效果且授权有效时才重新进入 QUEUED。无法判明进入 NEEDS_ATTENTION 的 Task 并保留未知 run；禁止把超时统一视为失败自动重试。

取消递增 cancel_generation。未派发 run 直接取消；已派发发出 cancel 请求，并继续收集最终证据。返回的 cancel_ack 仅表示请求被接受；实际效果可能已经发生。若效果已发生，记录事实和取消竞争，不把运行改写为从未执行。

## 5. 租约与许可

默认租约 30 秒，心跳每 10 秒；每次重新领取递增 fencing_token。所有进度和回执必须匹配 run_id、attempt_no、fencing_token。旧 token 回执保留审计但不能覆盖当前运行状态，必要时触发对账。

派发前校验：capability 注册版本、授权有效期与 scope、authorization revision、task cancel_generation、任务剩余预算、executor 身份和当前 fencing_token。许可记录 permission_id 在同一短事务生成，scope 指定实体、字段、目标路径／来源以及允许操作；token 不进入模型 Context 或日志。

WorldCommitService 的许可校验和事实写入同事务，能防止检查后本地授权被撤回的竞争。外部设备或服务调用无法与本地事务原子提交：撤回生效后禁止新的派发，但此前已派发的效果必须如实对账；不得声称本地 fencing 可以阻止所有外部重复效果。

## 6. 能力契约

| 能力 ID | 运行位置 | 副作用和验证 |
|---|---|---|
| `notify.local` | P2 | 持久 CLI 通知；按通知 ID 去重，CLI 确认收取 |
| `alarm.play` | P2 | 本地文件播放；查播放会话；测试默认静音适配器 |
| `alarm.stop` / `alarm.snooze` | P2 控制 | 指定会话停止；延后创建新 once job 并去重 |
| `artifact.write` | P2 | 仅测试工作目录原子写文件，以哈希验证 |
| `source.sync` | P1 adapter | 来源页落库和 cursor；阶段 3 限 fixture |
| `briefing.build` | P1 内置 agent | 有引用的文字产物；不自动发送外部消息 |
| `memory.refresh` | P1 内置 agent | 更新指定 24 小时槽的派生快照 |
| `world.update` | P1 内置 agent + CommitService | 仅许可范围内事实更新，验证新版本和审计 |
| `memory.search` | P1 | 只读分页检索，服从披露和预算 |

每项登记参数 Schema、result Schema、side_effect_class、supports_idempotency、supports_query、supports_cancel、timeout_ms。默认最多 3 次尝试（含首次），两次重试间隔为 1 秒和 5 秒；memory.refresh 采用 MemoryPolicy 中较长的间隔。某能力不支持幂等和查询时，派发后未知结果不重试。P1 工作适配器也必须先登记 incoming run 再调用模型，重复派发返回同一工作结果。

P1 将收件写入 core_work，绑定 run_id、command_hash 和当前 fencing；重启从 checkpoint 恢复。WorldCommitService 在事实提交事务内同时更新 core_work 的最终结果，因此 P2 未收到通知时可查询，不会再次修改事实。旧 attempt 的已保存结果作为对账证据返回，P2 验证后登记当前对账结论；不能把旧 receipt 直接当作新 fencing 的执行回执。

内置 agent 默认每个根意图模型调用不超过 8 次、检索 3 次、动作 10 次、重规划 2 次、累计输出 token 16,000、执行活跃时间 5 分钟。等待期间不计活跃时间，但 Task 有 deadline_at。预算账本落库，触发子任务共享 root_id，不能通过生成新 ID 清零。每次模型调用先预留次数与输出上限再结算；崩溃后未结算的调用保留预留消耗，不能通过重启获得免费额度。

日历／间隔计划的每次独立 occurrence 由 Scheduler 分配新的执行 root，Task.parent_root_id 指向计划的触发根；这样正常周期计划不会因累计运行次数而永久耗尽单任务预算。事件引发的子任务沿用事件 root，不以新 occurrence 清零自激链预算。只有 Scheduler 的时间触发或新认证输入能开启新的独立根。

## 7. WAIT、REPLAN 与目标验收

结构化控制支持 WAIT、REPLAN、SUBMIT_ARTIFACT、REQUEST_COMPLETION 和 READ_MEMORY。WAIT 仅接受注册事件类型、对象 ID、状态值和超时；不执行模型生成的查询代码。

WAIT 登记在一个事务读取当前事件水位、检查条件、保存 wait generation 和 cursor；若条件已经满足，立即入队。消费者从 cursor 之后读取事件，再按当前状态复查，不把事件文本本身当作条件成立。触发与 Task 状态、游标提交原子化，旧 generation 不能唤醒新等待；重启补扫且超时持久化。REPLAN 不变更 criterion，SUBMIT_ARTIFACT 仅追加证据，REQUEST_COMPLETION 调用独立确定性 Verifier。

Verifier 初版覆盖 `artifact_hash_matches`、`notification_recorded`、`world_revision_matches`、`source_cursor_committed`、`master_confirmed`；自述成功不属于证据。业务标准无法机器验证时保持等待真实反馈，不能用另一个模型赞同替代。与数据库同一证据导出的两段文本算同一来源。

## 8. 防止事件循环

ChangeEvent 带 root_id、causation_id 和 origin。消费者忽略自己已处理的事件；订阅禁止由同一 root 的无状态变化事件再次触发相同规则。root 总动作预算、同一规则冷却默认 60 秒、连续 3 次无进展停止规则均持久化。重启不得重新授予预算。Replay 模式禁用所有真实执行器和外发，不能重发历史提醒。

## 实施过程中发现的缺陷 D02：周期通知的实例身份

2026-09-14 实施发现：周期计划若复用模板 notification_key，notification 全局唯一约束会使后续 occurrence 复用旧通知及验收证据。经本地 Ayanami 同意，Scheduler 在每个 occurrence 的原子物化事务内，将 notify.local 模板键实例化为 `occ:v1:<base64url(template_key)>:<base64url(occurrence_key)>`（无填充 Base64 URL 编码）。同一 occurrence 的重试/对账复用实例键，不包含 attempt、job_revision 或当前墙钟。模板键保持不变。

实例 Command.arguments.notification_key 与该实例 notification_recorded criterion.expected.notification_key 同步绑定后，才计算并冻结 criterion_hash。不得更改已存在 Task 的完成条件；修订模板仅作用于以后尚未物化的 occurrence。通知验收须同时核对实例键、当前 run 的持久通知及真实执行证据，不能用另一个 occurrence 的通知完成本次 Task。即时独立任务仍按其已接受的稳定通知键处理。

修订同时适用于时间、事件和手动 occurrence；跳过的 occurrence 不产生通知。复核依据：[Ayanami D02 讨论结论](../review/D02-notification-occurrence.response.md).

## 实施过程中发现的缺陷（D05，2026-09-14）

经 Ayanami 与实施方商议（`review/D05-consciousness-criterion.response.md`），补充 `consciousness_slot_committed`，其 expected 严格为 `{ "slot": 非负整数 }`。Verifier 必须按精确 slot 读取持久 ConsciousnessState，执行完整 DTO 校验并确认 DTO.slot 一致；不得以 MAX(slot) 或未来槽替代。仅程序 SlotController 可生成 memory.refresh，按固定 epoch/slot 派生稳定 root/request/intent 与 operation_key=memory_refresh；P2 登记持久任务，Core 使用命令目标 slot，不能重算成另一个槽。重复/重启复用既有命令；每槽最多三次，失败重试分别延后5分钟、30分钟。时钟前跳只登记当前槽并取消未派发旧槽，回拨不生成历史槽。初次 bootstrap 同样走持久命令。验收覆盖重复、精确槽、并发同槽与重启恢复；DDL 不变。


## D06 实施缺陷修正（2026-09-14）

实施过程中发现：仅计算下一个有效 UTC 时刻会跳过 DST gap 的审计。Ayanami 复核 D06 后增加 `scheduled_job.skipped` 审计事件。不存在的本地日期/时刻不伪造 JobRun.scheduled_for；事件与 next_due_at 推进同事务，before 为事务读到的完整计划，after 为推进运行字段后的完整计划，业务 revision 不增加。事件 origin 固定 scheduler.calendar，extensions.runtime.calendar_skip 记录 local_date、timezone、local_time、reason=DST_GAP。事件 ID 由 job_id、本地日期与规范规则哈希确定；相同事件重放核对语义后不阻断推进。该审计事件不能触发事件规则。

复核依据：`review/D06-calendar-skip.response.md`。


## 实施过程中发现的缺陷：D08 能力准入与固定验收条件

实施发现 `alarm.play`、`briefing.build`、`source.sync` 已有执行器，但公共准入的程序派生与 Criterion 判别联合不完整。经 [Ayanami D08 复核](../review/D08-capability-criteria-deepseek.response.md) 同意，新增以下严格闭合的 kind，schema_version 保持 1；登记时冻结 criterion_hash，模型必须逐字段匹配程序派生值，不得事后改写。

- `alarm_session_recorded`：expected 仅 `{device_id, audio_ref}`，audio_ref 为命令 ObjectRef 的 UUID。Verifier 解析 Task 当前 run，交叉核对 alarm.play 及 args，并要求该 run 的会话 DTO 身份一致、状态 PLAYING 或 STOPPED。稍后提醒的新 Task/run 不得复用旧会话；不需要 D02 通知键实例化，因为会话按 run 绑定。PASS 仅证明已持久记录播放会话，不等于已叫醒、真实发声或 Item DONE；静音断言属于 A21 测试。
- `briefing_artifact_recorded`：expected 仅 `{media_type: "text/plain"}`。要求当前 run 当前 attempt/fence 的最终持久成功 receipt、effect_observed=true、至少一个非空对象，ObjectRef 与对象记录一致，实际字节 SHA256 自洽。旧回执、缺失或损坏对象不能 PASS。只证明产物持久化，不证明内容正确或有引用；不得读取模型自述判定 verdict，也不得事后回填 hash 自证。
- `source_sync_recorded`：expected 仅 `{source_id: UUID}`。当前 run 命令参数必须一致；SourceState 全 DTO 与 SQL 镜像一致且 cursor 非 NULL；追加 source.synced 事件必须带当前 run/attempt/fence provenance。`runtime.source_sync` 严格包含 `{run_id: UUID, attempt_no: integer>=1, fencing_token: integer>=1, records_processed: integer>=0}`，由 IngestService 在 SourceSynced 的同一事务内写入事件，禁止模型提供。其 records_processed 与事件 after.cursor.processed 一致。后续同步不覆盖旧事件。原 source_cursor_committed 保留旧语义；拒绝准入期猜测 cursor_hash 或依赖可变 fixture 内容计算标准。

三个新判定任一必要证据缺失或不一致均 UNKNOWN，不弱化 CRITERION_TAMPERED、授权和 fencing 检查。D05 memory.refresh 仍由专属 SlotController 登记，禁止普通公共准入。


### D08 修订 1：REPLAN 的当前 run 定义

前轮“同 Task 总共恰一条 run”的规则与合法 REPLAN 保留历史 run 冲突，已由 [Ayanami 补充裁决](../review/D08-replan-current-run-deepseek.response.md) 纠正。当前 run = 同 Task `ORDER BY rowid DESC LIMIT 1` 的最新已接纳 run，和 REPLAN 选择 previous 的追加顺序相同。只查询其证据；禁止按成功状态回捞历史 run。任何更旧 run 仍为 QUEUED/CLAIMED/RUNNING/RESULT_UNKNOWN 都令新判定 UNKNOWN；当前 RESULT_UNKNOWN 须先完成对账。列与 DTO 的 ID/task/attempt/fence/state 始终交叉核对。

本规则依赖 job_run 只追加、不 DELETE、不 VACUUM 的存储不变量，插入与 REPLAN 修改在同一写事务内；当前无清理这类行的实现。未来引入清理/整理必须先迁移为显式 current_run_id 或代际，不能悄然沿用 rowid 假设。alarm 证据是 run 级（同 run 回收不额外要求会话 fence）；briefing receipt 和 source event 仍要求当前 attempt/fence。新标准内容和 criterion_hash 不改变，旧证据不满足新 REPLAN、连续两次 REPLAN 只认最后一代、重启不改变归属。

## 实施过程中发现的缺陷（D10，2026-09-14）

实际自然语言 CLI 提醒回放发现：模型未收到既有提醒默认规则，生成 SKIP/0 秒，正常扫描迟到 904 毫秒就合法跳过。根据 Ayanami DeepSeek 商议（`review/reminder-defaults-v1-boundary-deepseek.response.md`、`review/reminder-defaults-scope-deepseek.response.md`），v1 自然语言 Decision 的 CREATE_JOB 在 capability 为 notify.local 或 alarm.play 时，只支持 FIRE_ONCE_WITHIN_GRACE 与 grace_seconds=300。非默认整笔决策拒绝并反馈 REMINDER_POLICY_UNSUPPORTED，沿用既定最多三次生成及持久预算，不静默改值或回填。其他能力的计划不受此限制。

自定义迟到策略须由已认证 Typed 入口显式提交，模型不得通过该入口代填。自然语言明确要求自定义策略时，只说明此能力边界，不生成替代默认动作；“一次”表示 occurrence 数量，不表示允许迟到跳过。系统说明与拒绝反馈都须陈述此边界。原 Scheduler 的严格宽限语义不变，Typed 的显式 SKIP/0 原样保留。原文子串或模型自填锚点不作为授权证明。

### 实施缺陷修复：Issue #1 AUD-02 / AUD-04

依据 `review/issue1-AUD02-AUD04-design-correction.response.md` 与 `review/issue1-memory-reconcile-clarification.response.md` 的 Ayanami 裁决：业务执行沿用请求取消；仅清理、已存证据查验和 CoreWork 收尾使用脱离已取消请求且最多 5 秒的上下文。收尾必须同时绑定持久 Run/Task、command hash、attempt 与 fence；允许当前 RUNNING 或 RESULT_UNKNOWN，不允许旧代覆盖。取消代次只能在 Task 已 CANCELLED 时保存晚到回执审计，沿用 `runtime.cancellation`，不能复活 Task。

同代尚在处理的重复 POST 返回 WORK_IN_PROGRESS。Runner 对 UNKNOWN 的 GET 只读；确定 FAILED/no-effect 可以按既有预算和退避重试，即使对应 execution_attempt 已 FINISHED，active_ms 也只能结算一次。跨代仅允许可验证 SUCCEEDED 证据重绑定，旧 FAILED 不能成为新代失败或重试凭据。

briefing 的 ObjectRef 与 CoreWork 成功回执使用同一 WriteObjects 事务。memory.refresh 的宕机间隙由 Runner 在本地事务核验精确 slot、合法 DTO、控制器 root 与当前 run/attempt/fence，先保存程序对账回执，再走 RecordReceipt/Verifier；GET 不进行该写入，缺失精确证据保持 UNKNOWN。source.sync 进入适配器后出现失败可能有部分效果，保持 RESULT_UNKNOWN；读取前拒绝则无业务效果。来源文件实际读取上限为 1 MiB + 1，超过 1 MiB 返回 INPUT_TOO_LARGE；不能仅依赖预先 Stat，且拒绝非普通文件。

## Issue #2：对话消费与执行进程独立

主对话按持久受理序号在单消费者锁下运行，模型调用期间无数据库长事务。冻结的轮次前缀排除后续未处理输入；认知提交后再处理下一轮。同步 Typed 写入遇到主轮处理中按 AUTHORITY_BUSY 拒绝并保持零准入副作用，精确旧请求仍可重放。

此对话顺序不将任务执行绑到终端。TUI 退出/断网只结束前端观察，Runner 继续处理已登记计划；取消、暂停、恢复、触发与通知确认使用已有认证业务接口和版本/幂等键。客户端不能将受理、执行成功、验收完成和 RESULT_UNKNOWN 混成一个成功状态。
